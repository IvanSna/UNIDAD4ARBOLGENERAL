/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Takitos13
 */
public class ArbolGeneral {
    NodoGeneral raiz;
    int x=0;
    int y=0;
    
    public ArbolGeneral(){
        raiz=null;
    }
    
    public boolean insertar (char dato, String path){
        if(raiz==null){
            raiz=new NodoGeneral(dato);
            if(raiz==null)return false;
            return true;
        }
        if(path.isEmpty()) return false;
        
        NodoGeneral padre= buscarNodoVersion2(path,path);
        if(padre==null) return false;
        
        //NodoGeneral hijoYaExiste= buscarNodoVersion2 (path, path);
        //if(hijoYaExiste!=null) return false;
        
        NodoGeneral nuevo =new NodoGeneral(dato);
        return padre.enlazar(nuevo);
    }
       
    private NodoGeneral buscarNodo(String path){
        path=path.substring(1);
        String vector[]=path.split("/");
        if(vector[0].charAt(0)== raiz.dato){
            if(vector.length==1) return raiz;
            NodoGeneral padre=raiz;
           
            for(int i=1; i<vector.length;i++){
                padre=padre.obtenerHijo(vector[i].charAt(0));
                if(padre==null)return null;
            }
            return padre;
        }
        return null;    
    }
    
    
    public boolean eliminar (String path){
        if(raiz==null) return false;
        NodoGeneral hijo = buscarNodoVersion2(path,path);
        if(hijo == null) return false;
        
        //si es rama no se puede eliminar retorna un false
        if(!hijo.esHoja()) return false;
        
        if(hijo == raiz){
            raiz= null;
            return true;
        }
        
        String pathPadre=obtenerPathPadre(path);
        NodoGeneral padre= buscarNodoVersion2(path,path);
        
        return padre.desenlazar(hijo);
    }

    
    
    private String obtenerPathPadre(String path) {
        int posicionANTESUltimaDiagonal=path.lastIndexOf("/")-1;
        return path.substring(0, posicionANTESUltimaDiagonal);
    }
    
    /*
        no es necesario hacerlo vector    
    */
    
    private NodoGeneral buscarNodoVersion2(String path , String temp2){ 
        path = path.substring(1);
        x = path.length();
        y = temp2.length();
        y = y /2 ;
        if(temp2.charAt(1) == raiz.dato){

           if(y==1) return raiz;
            NodoGeneral padre = raiz;
                
            if(x==0){
                padre = padre.obtenerHijo(path.charAt(0));
                buscarNodoVersion2(path.substring(1), temp2);
            }
            if(padre == null) return null;
            return padre;
        }
        return null;   
    }
}
